//
//  AppDelegate.h
//  MultipleTargetsDemo
//
//  Created by wyy on 2016/12/4.
//  Copyright © 2016年 wyy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

